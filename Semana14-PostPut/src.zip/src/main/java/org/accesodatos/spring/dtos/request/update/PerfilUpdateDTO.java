package org.accesodatos.spring.dtos.request.update;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;


@Data
public class PerfilUpdateDTO {
    @Size(max = 100, message = "El nombre completo no puede superar los 100 caracteres")
    private String nombreCompleto;

    @Pattern(regexp = "[0-9]*", message = "El teléfono solo puede contener números")
    private String telefono;

    @Size(max = 50, message = "La dirección no puede superar los 50 caracteres")
    private String direccion;
}
